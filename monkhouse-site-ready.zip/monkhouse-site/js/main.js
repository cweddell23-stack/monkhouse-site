// Monkhouse — main.js
// Mobile nav toggle (with accessibility niceties)
const navToggle = document.getElementById("navToggle");
const nav = document.getElementById("nav");

function setNav(open) {
  if (!nav || !navToggle) return;
  nav.classList.toggle("open", open);
  navToggle.setAttribute("aria-expanded", String(open));
}

if (navToggle && nav) {
  navToggle.setAttribute("aria-controls", "nav");
  navToggle.setAttribute("aria-expanded", "false");

  navToggle.addEventListener("click", () => {
    const open = !nav.classList.contains("open");
    setNav(open);
  });

  // Close on Escape
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") setNav(false);
  });

  // Close if you click outside
  document.addEventListener("click", (e) => {
    if (!nav.classList.contains("open")) return;
    const target = e.target;
    if (!(target instanceof Element)) return;
    const clickedInside = nav.contains(target) || navToggle.contains(target);
    if (!clickedInside) setNav(false);
  });
}

// Footer year
const yearEl = document.getElementById("year");
if (yearEl) yearEl.textContent = new Date().getFullYear();

// Highlight active nav item
(function markActive() {
  const path = (location.pathname.split("/").pop() || "index.html").toLowerCase();
  document.querySelectorAll('nav a[href]').forEach(a => {
    const href = (a.getAttribute("href") || "").toLowerCase();
    if (href === path) a.classList.add("active");
  });
})();
