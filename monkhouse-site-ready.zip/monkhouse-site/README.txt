# Monkhouse Static Site (ready to upload)

Upload this folder contents to:
- Netlify (drag/drop the whole folder), or
- GitHub Pages (commit folder contents to your repo root), or
- Any static host.

Folder structure:
- index.html
- locations.html / narrators.html / artifacts.html / timeline.html / listen.html
- css/style.css
- js/main.js
